import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { from } from 'rxjs';
import {ShoppingDashboardPage} from '../app/shopping-dashboard/shopping-dashboard.page'

const routes: Routes = [
  {
    path: '',
    redirectTo: 'folder/My-shop',
    pathMatch: 'full'
  },
  {
    path: 'folder/:id',
    loadChildren: () => import('./folder/folder.module').then( m => m.FolderPageModule)
  },
  {
    path: 'shopping-dashboard',
    loadChildren: () => import('./shopping-dashboard/shopping-dashboard.module').then( m => m.ShoppingDashboardPageModule)
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
