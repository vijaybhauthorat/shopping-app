import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shopping-dashboard',
  templateUrl: './shopping-dashboard.page.html',
  styleUrls: ['./shopping-dashboard.page.scss'],
})
export class ShoppingDashboardPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
