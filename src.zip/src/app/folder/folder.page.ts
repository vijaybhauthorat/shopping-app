import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-folder',
  templateUrl: './folder.page.html',
  styleUrls: ['./folder.page.scss'],
})
export class FolderPage implements OnInit {
  public folder: string;
  public shopName = [
    { title: 'Left Shopping Window', number: '12 Accessories', status: 'On' },
    { title: 'Right Shopping Window Front Window', number: '9 Accessories', status: 'On' },
    { title: 'Front Entrance', number: '12 Accessories', status: 'On' },
    { title: 'Shoe Wall', number: '20 Accessories', status: 'Off' },

  ];

  constructor(private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.folder = this.activatedRoute.snapshot.paramMap.get('id');
  }

}
